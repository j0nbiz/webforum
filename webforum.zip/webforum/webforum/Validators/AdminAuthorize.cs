﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace webforum.Validators {
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class AdminAuthorize : AuthorizeAttribute {
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext) {
            if (filterContext.RequestContext.HttpContext.User.Identity.IsAuthenticated) {
                filterContext.Controller.TempData.Add("RedirectReason", "Unauthorized");
            }
            base.HandleUnauthorizedRequest(filterContext);
        }
    }
}
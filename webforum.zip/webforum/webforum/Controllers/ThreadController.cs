﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using webforum.Models;

namespace webforum.Controllers
{
    public class ThreadController : Controller
    {
        private ForumDB db = new ForumDB();

        [Authorize]
        // GET: Create
        public ActionResult Create() {
            return View();
        }

        // POST: Create
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "title, tags, content")] thread thread) {
            if (ModelState.IsValid) {
                // Check input
                if (thread.title != null && thread.tags != null && thread.content != null) {
                    // Fill missing thread info
                    thread.username = (string)Session["username"];
                    thread.date = DateTime.Now;

                    db.threads.Add(thread);
                    db.SaveChanges();

                    return RedirectToAction("Index", "Home");
                } else {
                    ModelState.AddModelError("", "Please fill in the required fields!");
                }
            }
            return View();
        }

        // GET: Goto
        public ActionResult Goto(int? thread_id) {
            if (thread_id == null) {
                return RedirectToAction("Index", "Home");
            }

            var thread = db.threads.Find(thread_id);

            // Increment the view since user viewed it
            thread.views++;

            db.Entry(thread).State = EntityState.Modified;
            db.SaveChanges();

            // Fill ViewBag with comments from thread
            if (ModelState.IsValid) {
                ViewBag.comments = (from c in db.comments
                                         where c.target_thread_id == thread_id && c.target_comment_id == null
                                         select c).ToList();
            }

            return View(thread);
        }

        // POST: Upvote
        [Authorize]
        public ActionResult Upvote(int? thread_id, bool upvote, string returl) {
            if (thread_id == null) {
                return RedirectToAction("Index", "Home");
            }

            var thread = db.threads.Find(thread_id);

            // Increment upvote if bool is true else downvote
            if (upvote) {
                thread.upvotes++;
            } else {
                thread.upvotes--;
            }
            
            db.Entry(thread).State = EntityState.Modified;
            db.SaveChanges();

            ViewBag.returl = returl;
            return View();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using webforum.Models;

namespace webforum.Controllers
{
    public class HomeController : Controller
    {
        private ForumDB db = new ForumDB();

        // GET: Home
        public ActionResult Index()
        {
            var query = (from t in db.threads
                         orderby t.date descending
                         select t).ToList();

            return View(query);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using webforum.Models;

namespace webforum.Controllers
{
    public class CommentController : Controller
    {
        private ForumDB db = new ForumDB();

        // POST: Create
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Reply([Bind(Include = "content")] comment comment, int? target_thread_id, int? target_comment_id, string returl) {
            if (ModelState.IsValid) {
                // Check input
                if (comment.content != null) {
                    // Fill missing thread info
                    comment.target_thread_id = (int)target_thread_id;
                    if (target_comment_id != null) { comment.target_comment_id = target_comment_id; }
                    comment.username = (string)Session["username"];
                    comment.date = DateTime.Now;

                    db.comments.Add(comment);
                    db.SaveChanges();
                } else {
                    ModelState.AddModelError("", "Please fill in the required fields!");
                }
            }

            return RedirectToAction("Goto", "Thread", new { thread_id = target_thread_id });
        }

        // POST: Upvote
        [Authorize]
        public ActionResult Upvote(int? comment_id, bool upvote, string returl) {
            if (comment_id == null) {
                return RedirectToAction("Index", "Home");
            }

            var comment = db.comments.Find(comment_id);

            // Increment upvote if bool is true else downvote
            if (upvote) {
                comment.upvotes++;
            } else {
                comment.upvotes--;
            }

            db.Entry(comment).State = EntityState.Modified;
            db.SaveChanges();

            ViewBag.returl = returl;
            return View();
        }
    }
}
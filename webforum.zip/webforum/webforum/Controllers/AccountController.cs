﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using webforum.Models;

namespace webforum.Controllers
{
    public class AccountController : Controller
    {
        private ForumDB db = new ForumDB();

        [Authorize]
        public ActionResult Logout() {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        // GET: Login
        public ActionResult Login(string returl) {
            // Check if user already logged in
            if (User.Identity.IsAuthenticated) {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.returl = returl;
            return View();
        }

        // POST: Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login([Bind(Include = "username, password")] user user, string returl) {
            if (ModelState.IsValid) {
                // Get updated user
                var query = (from u in db.users
                             where u.username == user.username && u.password == user.password
                             select u).FirstOrDefault();

                if (query != null) {
                    Session["username"] = query.username;
                    Session["user_id"] = query.user_id;

                    FormsAuthentication.RedirectFromLoginPage(query.username, false);
                } else {
                    ModelState.AddModelError("", "Invalid username or password!");
                }
            }
            ViewBag.returl = returl;
            return View();
        }

        // GET: Register
        public ActionResult Register(string returl) {
            ViewBag.returl = returl;
            return View();
        }

        // POST: Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register([Bind(Include = "username, password, firstname, lastname, email")] user user, string returl) {
            if (ModelState.IsValid) {
                // Check input
                if (user.username != null && user.password != null && user.firstname != null && user.lastname != null) {
                    db.users.Add(user);
                    db.SaveChanges();
                } else {
                    ModelState.AddModelError("", "Please fill in the required fields!");
                }

                // Get updated user
                var query = (from u in db.users
                             where u.username == user.username && u.password == user.password
                             select u).FirstOrDefault();

                if (query != null) {
                    Session["username"] = query.username;
                    Session["user_id"] = query.user_id;

                    FormsAuthentication.RedirectFromLoginPage(query.username, false);
                }
            }
            ViewBag.returl = returl;
            return View();
        }

        //GET: Edit
        [Authorize]
        public ActionResult Edit(int? user_id, string returl) {
            if (user_id == null) {
                return RedirectToAction("Index", "Home");
            }

            if ((int)Session["user_id"] != user_id) {
                return RedirectToAction("Index", "Home");
            }
            var user = db.users.Find(user_id);
            ViewBag.returl = returl;
            return View(user);
        }

        // POST: Edit
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "password, firstname, lastname, email")] user user, string returl) {
            if (ModelState.IsValid) {
                // Check input
                if (user.password != null && user.firstname != null && user.lastname != null) {

                    // Fill missing user info
                    user.user_id = (int)Session["user_id"];
                    user.username = (string)Session["username"];
                    
                    db.Entry(user).State = EntityState.Modified;
                    db.SaveChanges();

                    return RedirectToAction("Index", "Home");
                } else {
                    ModelState.AddModelError("", "Please fill in the required fields!");
                }
            }
            ViewBag.returl = returl;
            return View(user);
        }
    }
}